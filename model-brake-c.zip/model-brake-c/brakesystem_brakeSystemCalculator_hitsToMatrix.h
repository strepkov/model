#ifndef BRAKESYSTEM_BRAKESYSTEMCALCULATOR_HITSTOMATRIX
#define BRAKESYSTEM_BRAKESYSTEMCALCULATOR_HITSTOMATRIX
#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif
#include "armadillo.h"
using namespace arma;
class brakesystem_brakeSystemCalculator_hitsToMatrix{
public:
double element[9];
mat matrix;
void init()
{
matrix=mat(3,3);
}
void execute()
{
for( auto i=1;i<=3;++i){
for( auto j=1;j<=3;++j){
matrix(i-1, j-1) = element[(i-1-1)*3+j-1];
}
}
}

};
#endif
