#ifndef BRAKESYSTEM_BRAKESYSTEMCALCULATOR_BRAKEDISTANCE_1_
#define BRAKESYSTEM_BRAKESYSTEMCALCULATOR_BRAKEDISTANCE_1_
#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif
#include "armadillo.h"
using namespace arma;
class brakesystem_brakeSystemCalculator_brakeDistance_1_{
public:
double brakeAcceleration;
double velocity;
double distance;
void init()
{
}
void execute()
{
distance = velocity*velocity/(2*brakeAcceleration);
}

};
#endif
