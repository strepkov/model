#ifndef BRAKESYSTEM_BRAKESYSTEMCALCULATOR_ADD_1_
#define BRAKESYSTEM_BRAKESYSTEMCALCULATOR_ADD_1_
#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif
#include "armadillo.h"
using namespace arma;
class brakesystem_brakeSystemCalculator_add_1_{
public:
double in1;
double in2;
double sum;
void init()
{
}
void execute()
{
sum = in1+in2;
}

};
#endif
