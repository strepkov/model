#ifndef BRAKESYSTEM_BRAKESYSTEMCALCULATOR_BRAKEVELOCITY_1_
#define BRAKESYSTEM_BRAKESYSTEMCALCULATOR_BRAKEVELOCITY_1_
#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif
#include "armadillo.h"
#include "HelperA.h"
using namespace arma;
class brakesystem_brakeSystemCalculator_brakeVelocity_1_{
public:
double brakeAcceleration;
double distance;
double velocity;
void init()
{
}
void execute()
{
velocity = (sqrt(2*brakeAcceleration*distance));
}

};
#endif
